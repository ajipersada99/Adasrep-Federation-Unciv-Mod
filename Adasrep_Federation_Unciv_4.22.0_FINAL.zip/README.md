# Adasrep Federation — Unciv 4.22.0

Finalized extension mod package for Unciv 4.22.0.

## Package structure
- `jsons/ModOptions.json` — extension-mod metadata
- `jsons/Nations.json` — Adasrep Federation
- `jsons/Units.json` — Pemanah Beruntun
- `jsons/Buildings.json` — Baricade
- `jsons/UnitPromotions.json` — custom promotions
- `Images/` — nation and promotion icons

## Compatibility
Designed for Unciv 4.22.0 as an extension mod. It should be enabled together with the Civ V base ruleset.

## Important
The Conquer promotion uses the supported Unciv unique `May capture killed [Military] units`. An inline percentage chance was removed because it is not a supported unique syntax in the current Unciv documentation.
