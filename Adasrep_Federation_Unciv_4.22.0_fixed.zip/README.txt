Adasrep Federation - Unciv 4.22.0

This is a partial ruleset mod for Unciv 4.22.0.

Contents:
- Adasrep Federation / Omnipotent Policy
- Baricade replaces Barracks, grants 8500 XP and the Rejuvenation, March, Command, Conquer, and Search and Find promotions to newly trained Military units in that city.
- Pemanah Beruntun replaces Composite Bowman (Strength 10, Ranged Strength 15) and starts with Rapid Fire and Hold the Line.
- Custom promotions: Rapid Fire, Hold the Line, Command, Conquer, Search and Find.

The JSON uses Unciv Unique syntax documented for the 4.x ruleset system.
